package com.role.implementation.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.role.implementation.model.UserLoans;

@Repository
public interface UserLoansRepository extends JpaRepository<UserLoans, Long> {

	public List<UserLoans> findByUserId(long userId);
	
}
