package com.role.implementation.controller;

import java.security.Principal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.role.implementation.DTO.UserLoansDTO;
import com.role.implementation.DTO.UserLoginDTO;
import com.role.implementation.DTO.UserRegisteredDTO;
import com.role.implementation.model.Loans;
import com.role.implementation.model.User;
import com.role.implementation.model.UserLoans;
import com.role.implementation.repository.LoanRepository;
import com.role.implementation.repository.UserLoansRepository;
import com.role.implementation.repository.UserRepository;
import com.role.implementation.service.DefaultUserServiceImpl;

@Controller
public class HomeLoanController {

	@Autowired
	UserRepository userRepository;

	@Autowired
	private LoanRepository loanRepo;

	@Autowired
	DefaultUserServiceImpl userDetailsService;

	@Autowired
	private UserLoansRepository userLoansRepository;

	@ModelAttribute("user")
	public UserLoginDTO userLoginDTO() {
		return new UserLoginDTO();
	}

	@ModelAttribute("userreg")
	public UserRegisteredDTO userRegistrationDto() {
		return new UserRegisteredDTO();
	}

	@GetMapping("/registration")
	public String showRegistrationForm() {
		return "register";
	}

	@PostMapping("/registration")
	public String registerUserAccount(@ModelAttribute("userreg") UserRegisteredDTO registrationDto) {
		userDetailsService.save(registrationDto);
		return "redirect:/login";
	}

	@GetMapping("/login")
	public String login() {
		return "login";
	}

	@PostMapping("/login")
	public void loginUser(@ModelAttribute("user") UserLoginDTO userLoginDTO) {
		System.out.println("Login method");
		userDetailsService.loadUserByUsername(userLoginDTO.getUsername());
	}

	@GetMapping("/adminScreen")
	public String adminUserPage(Model model, Principal principal) {

		//UserDetails userDetails = userDetailsService.loadUserByUsername(principal.getName());
		 User user = userRepository.findByEmail(principal.getName());
		
		 List<UserLoans> userloans = userLoansRepository.findAll();
		 List<Long> loanIDs = userloans.stream().map(UserLoans::getLoanId).collect(Collectors.toList());
		 List<Long> userIds = userloans.stream().map(UserLoans::getUserId).collect(Collectors.toList());
		 List<Loans> loans = loanRepo.findAllById(loanIDs);
		 List<User> users = userRepository.findAllById(userIds);
		 List<UserLoansDTO> userLoanDetails = new ArrayList<>();
		 
		Map<Long, String> loansMap = loans.stream().collect(Collectors.toMap(Loans::getLoanId, Loans::getLoanName));
		Map<Long, String> userMap = users.stream().collect(Collectors.toMap(User::getId, User::getName));
		 
		 userloans.stream().forEach(obj -> {
				UserLoansDTO userdto = new UserLoansDTO();
				userdto.setLoanId(obj.getLoanId());
				/*
				 * Optional<Loans> loan = loanRepo.findById(obj.getLoanId()); String loanName =
				 * loan.isPresent() ? loan.get().getLoanName() : null;
				 */
				userdto.setLoanName(loansMap.get(obj.getLoanId()));
				userdto.setUserName(userMap.get(obj.getUserId()));
				userLoanDetails.add(userdto);
			});

		model.addAttribute("userDetails", user.getName());
		model.addAttribute("loanDetails", userLoanDetails);
		return "adminScreen";
	}

	@GetMapping("/dashboard")
	public String userPage(Model model, Principal principal) {
		// UserDetails userDetails = userDetailsService.loadUserByUsername(principal.getName());
		
		User user = userRepository.findByEmail(principal.getName());

		List<UserLoans> userloans = userLoansRepository.findByUserId(user.getId());

		// List<UserLoans> userloans = userLoansRepository.findAll();
		List<Long> loanIDs = userloans.stream().map(UserLoans::getLoanId).collect(Collectors.toList());
		List<Loans> loans = loanRepo.findAllById(loanIDs);

		List<UserLoansDTO> userLoanDetails = new ArrayList<>();

		userloans.stream().forEach(obj -> {
			UserLoansDTO userdto = new UserLoansDTO();
			userdto.setLoanId(obj.getLoanId());
			Optional<Loans> loan = loanRepo.findById(obj.getLoanId());
			String loanName = loan.isPresent() ? loan.get().getLoanName() : null;
			userdto.setLoanName(loanName);
			userdto.setUserName(user.getName());
			userLoanDetails.add(userdto);
		});

		model.addAttribute("userDetails", "User " + principal.getName());
		model.addAttribute("loanDetails", userLoanDetails);
		return "dashboard";
	}
	
	@GetMapping("/loanDetails")
	public String getLoanDetails(Model model,@RequestParam(name= "loanId") Long loanId) {
		System.out.println("Loan Detials are ....."+loanId);
		
		Loans loan = new Loans();
		loan.setLoanId(12121l);
		loan.setLoanName("Test Loan");
		model.addAttribute("loanDetails", loan);
		return "loanDetails";
	}

	private String returnUsername() {
		SecurityContext securityContext = SecurityContextHolder.getContext();
		UserDetails user = (UserDetails) securityContext.getAuthentication().getPrincipal();
		User users = userRepository.findByEmail(user.getUsername());
		return users.getName();
	}

}
