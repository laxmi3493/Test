package com.logger.implementation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RoleBasedAuthenticationApplicationTests {

	@Test
	void contextLoads() {
	}

}
