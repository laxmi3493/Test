package com.role.implementation.controller;

import org.springframework.stereotype.Controller;

@Controller
public class HomeLoanController {
	/*
	 * 
	 * 
	 * @Autowired UserDetailsService userDetailsService;
	 * 
	 * @Autowired private DefaultUserService userService;
	 * 
	 * @GetMapping public String showRegistrationForm() { return "register"; }
	 * 
	 * @PostMapping public String registerUserAccount(@ModelAttribute("user")
	 * UserRegisteredDTO registrationDto) { userService.save(registrationDto);
	 * return "redirect:/login"; }
	 * 
	 * 
	 * @GetMapping("/login") public String login() { return "login"; }
	 * 
	 * @GetMapping("/registration") public String
	 * getRegistrationPage(@ModelAttribute("user") UserDto userDto) { return
	 * "register"; }
	 * 
	 * @PostMapping("/registration") public String saveUser(@ModelAttribute("user")
	 * UserDto userDto, Model model) { userService.save(userDto);
	 * model.addAttribute("message", "Registered Successfuly!"); return "register";
	 * }
	 * 
	 * 
	 * @GetMapping("user-page") public String userPage (Model model, Principal
	 * principal) { UserDetails userDetails =
	 * userDetailsService.loadUserByUsername(principal.getName());
	 * model.addAttribute("user", userDetails); return "user"; }
	 * 
	 * @GetMapping("admin-page") public String adminPage (Model model, Principal
	 * principal) { UserDetails userDetails =
	 * userDetailsService.loadUserByUsername(principal.getName());
	 * model.addAttribute("user", userDetails); return "admin"; }
	 * 
	 */}
