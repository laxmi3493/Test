package com.role.implementation.controller;

import java.security.Principal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.role.implementation.DTO.UserLoansDTO;
import com.role.implementation.model.Loans;
import com.role.implementation.model.User;
import com.role.implementation.model.UserLoans;
import com.role.implementation.repository.LoanRepository;
import com.role.implementation.repository.UserLoansRepository;
import com.role.implementation.repository.UserRepository;
import com.role.implementation.service.DefaultUserServiceImpl;




@Controller
//@RequestMapping("/dashboard")
public class DashboardController {
	
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private UserLoansRepository userLoansRepository;
	
	@Autowired
	DefaultUserServiceImpl userDetailsService;
	
	@Autowired
	LoanRepository loanRepo;
	
	@GetMapping("/dashboard1")
    public String displayDashboard(Model model){
		String user= returnUsername();
        model.addAttribute("userDetails", user);
        return "dashboard";
    }
	
	@GetMapping("/dashboard")
	public String userPage (Model model, Principal principal) {
		//UserDetails userDetails = userDetailsService.loadUserByUsername(principal.getName());
		User user = userRepository.findByEmail(principal.getName());
		//List<UserLoans> userloans = userLoansRepository.findByUserId(user.getId());
		
		List<UserLoans> userloans = userLoansRepository.findAll();
		List<Long> loanIDs =userloans.stream().map(UserLoans::getLoanId).collect(Collectors.toList());
		List<Loans> loans =  loanRepo.findAllById(loanIDs);
		
		List<UserLoansDTO> userLoanDetails = new ArrayList<>();
		
		userloans.stream().forEach( obj ->{
			UserLoansDTO userdto = new UserLoansDTO();
			userdto.setLoanId(obj.getLoanId());
			Optional<Loans> loan =loanRepo.findById(obj.getLoanId())  ;
			String loanName = loan.isPresent()?loan.get().getLoanName():null;
			userdto.setLoanName(loanName); 
			userdto.setUserName(user.getName());
			userLoanDetails.add(userdto);
		});
		
		model.addAttribute("userDetails", "User "+principal.getName() 
		//+" "+ userloans
		);
		//model.addAttribute("loanDetails",userLoanDetails);
		return "dashboard";
	}
	
	private String returnUsername() {
		SecurityContext securityContext = SecurityContextHolder.getContext();
        UserDetails user = (UserDetails) securityContext.getAuthentication().getPrincipal();
		User users = userRepository.findByEmail(user.getUsername());
		return users.getName();
	}
		
}
