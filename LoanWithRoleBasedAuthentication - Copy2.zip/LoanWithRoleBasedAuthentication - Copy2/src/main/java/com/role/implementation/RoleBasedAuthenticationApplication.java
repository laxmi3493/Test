package com.role.implementation;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.role.implementation.model.Loans;
import com.role.implementation.model.User;
import com.role.implementation.model.UserLoans;
import com.role.implementation.repository.LoanRepository;
import com.role.implementation.repository.OffersRepository;
import com.role.implementation.repository.UserLoansRepository;
import com.role.implementation.repository.UserRepository;


@SpringBootApplication
public class RoleBasedAuthenticationApplication {

	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private LoanRepository loanRepo;
	
	@Autowired
	private OffersRepository offerRepo;
	
	@Autowired
	private UserLoansRepository userLoanRepo;
	
	@PostConstruct
	public void initUser() {
	  
	  List<User> users = Stream.of(new User(101,"kiran","kiran@gmail.com","test123","ADMIN"),
	                                new User(102,"lucky","lucky@gmail.com","test123","USER"),
	                                new User(103,"ravi","ravi@gmail.com","test123","USER"),
	                                new User(102,"chinnu","chinnu@gmail.com","test123","USER")
	                                
			  ).collect(Collectors.toList());
	 
	userRepository.saveAll(users);
	
	List<Loans> loans =Stream.of(new Loans(201l, "HomeLoan-2023-Q1", "Home Loan offer for 2023 first quater"),
								new Loans(202l, "HomeLoan-2023-Q2", "Home Loan offer for 2023 second quater"),
								new Loans(203l, "HomeLoan-2023-Q3", "Home Loan offer for 2023 third quater")).collect(Collectors.toList());
	

	loanRepo.saveAll(loans);
	
	List<UserLoans> userLoans = Stream.of(
										new UserLoans(111l, 101l, 201l),
										new UserLoans(112l, 102l, 201l),
										new UserLoans(113l, 102l, 202l)).collect(Collectors.toList());
	
	
	userLoanRepo.saveAll(userLoans);
	
	
	}
	
	public static void main(String[] args) {
		SpringApplication.run(RoleBasedAuthenticationApplication.class, args);
	}

}
