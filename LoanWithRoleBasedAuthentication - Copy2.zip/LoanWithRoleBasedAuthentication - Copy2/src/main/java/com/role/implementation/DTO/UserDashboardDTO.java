package com.role.implementation.DTO;

import com.role.implementation.model.User;
import com.role.implementation.model.UserLoans;

public class UserDashboardDTO {
	
	private User user;
	
	private UserLoans userLoans;

}
