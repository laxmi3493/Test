package com.role.implementation.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity(name = "userloans")
public class UserLoans {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long ulId;
	@Column(name = "userId")
	private long userId;
	@Column(name = "loanId")
	private long loanId;

	public long getUlId() {
		return ulId;
	}

	public void setUlId(long ulId) {
		this.ulId = ulId;
	}

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public long getLoanId() {
		return loanId;
	}

	public void setLoanId(long loanId) {
		this.loanId = loanId;
	}

	public UserLoans(long ulId, long userId, long loanId) {
		super();
		this.ulId = ulId;
		this.userId = userId;
		this.loanId = loanId;
	}
	
	public UserLoans() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "UserLoans [ulId=" + ulId + ", userId=" + userId + ", loanId=" + loanId + "]";
	}
	
	

}
