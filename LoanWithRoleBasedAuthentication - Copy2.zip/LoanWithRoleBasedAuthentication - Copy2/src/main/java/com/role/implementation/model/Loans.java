package com.role.implementation.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity(name = "loans")
public class Loans {
	
	public Loans() {
		// TODO Auto-generated constructor stub
	}
	
	public Loans(long loanId, String loanName, String loanDesc) {
		super();
		this.loanId = loanId;
		this.loanName = loanName;
		LoanDesc = loanDesc;
	}
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long loanId;
	private String loanName;
	private String LoanDesc;
	public long getLoanId() {
		return loanId;
	}
	public void setLoanId(long loanId) {
		this.loanId = loanId;
	}
	public String getLoanName() {
		return loanName;
	}
	public void setLoanName(String loanName) {
		this.loanName = loanName;
	}
	public String getLoanDesc() {
		return LoanDesc;
	}
	public void setLoanDesc(String loanDesc) {
		LoanDesc = loanDesc;
	}
	@Override
	public String toString() {
		return "Loans [loanId=" + loanId + ", loanName=" + loanName + ", LoanDesc=" + LoanDesc + "]";
	}
	
	
	

	
	
}
